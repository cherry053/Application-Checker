# NSWRAGAPP
NSWRA Application Checker

## Running the app

```bash
pip install -r requirements.txt
streamlit run app.py
```

This opens the app in your browser (defaults to http://localhost:8501).

